#!/bin/bash

# to suppress the openmp warnings

export OMPI_MCA_btl=^openib 


